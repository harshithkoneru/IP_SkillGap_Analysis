// Update skill value display when slider changes
document.getElementById('htmlSkill').addEventListener('input', function() {
    document.getElementById('htmlValue').textContent = this.value;
});

document.getElementById('javaSkill').addEventListener('input', function() {
    document.getElementById('javaValue').textContent = this.value;
});

document.getElementById('sqlSkill').addEventListener('input', function() {
    document.getElementById('sqlValue').textContent = this.value;
});

// Form validation
function validateForm(event) {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();

    // Basic validation
    if (name === '') {
        alert('Please enter your name');
        event.preventDefault();
        return false;
    }

    if (email === '') {
        alert('Please enter your email');
        event.preventDefault();
        return false;
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address');
        event.preventDefault();
        return false;
    }

    return true;
}
