package com.skillgap.model;

public class Student {
    private int id;
    private String name;
    private String email;
    private int htmlSkill;
    private int javaSkill;
    private int sqlSkill;

    // Constructor
    public Student(String name, String email, int htmlSkill, int javaSkill, int sqlSkill) {
        this.name = name;
        this.email = email;
        this.htmlSkill = htmlSkill;
        this.javaSkill = javaSkill;
        this.sqlSkill = sqlSkill;
    }

    // Empty constructor
    public Student() {
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getHtmlSkill() {
        return htmlSkill;
    }

    public void setHtmlSkill(int htmlSkill) {
        this.htmlSkill = htmlSkill;
    }

    public int getJavaSkill() {
        return javaSkill;
    }

    public void setJavaSkill(int javaSkill) {
        this.javaSkill = javaSkill;
    }

    public int getSqlSkill() {
        return sqlSkill;
    }

    public void setSqlSkill(int sqlSkill) {
        this.sqlSkill = sqlSkill;
    }
}
