<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skill Gap Report</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .report-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .student-info {
            background: #f0f4ff;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
            border-left: 4px solid #667eea;
        }

        .student-info p {
            margin: 8px 0;
            color: #333;
        }

        .student-info strong {
            color: #667eea;
        }

        .report-title {
            color: #667eea;
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        th {
            background: #667eea;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 500;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        .priority-high {
            background: #ffe5e5;
            color: #c1272d;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 3px;
            display: inline-block;
        }

        .priority-medium {
            background: #fff3cd;
            color: #856404;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 3px;
            display: inline-block;
        }

        .priority-low {
            background: #d4edda;
            color: #155724;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 3px;
            display: inline-block;
        }

        .overall-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 5px;
            margin-bottom: 30px;
            text-align: center;
        }

        .overall-priority-value {
            font-size: 28px;
            font-weight: bold;
            margin: 15px 0;
        }

        .recommendations {
            background: #f0f8ff;
            padding: 20px;
            border-radius: 5px;
            border-left: 4px solid #17a2b8;
            margin-bottom: 30px;
        }

        .recommendations h3 {
            color: #17a2b8;
            margin-bottom: 15px;
        }

        .recommendations ul {
            list-style: none;
            color: #333;
        }

        .recommendations li {
            padding: 8px 0;
            padding-left: 25px;
            position: relative;
        }

        .recommendations li:before {
            content: "→";
            position: absolute;
            left: 0;
            color: #17a2b8;
            font-weight: bold;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn-primary {
            flex: 1;
            padding: 12px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            text-align: center;
            transition: background 0.3s;
        }

        .btn-primary:hover {
            background: #764ba2;
        }

        .btn-secondary {
            flex: 1;
            padding: 12px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            text-align: center;
            transition: background 0.3s;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        .gap-value {
            font-weight: bold;
            color: #c1272d;
        }
    </style>
</head>
<body>
    <div class="container" style="max-width: 800px;">
        <%
            // Get data from session
            String studentName = (String) session.getAttribute("studentName");
            Object studentObj = session.getAttribute("student");
            Integer studentId = (Integer) session.getAttribute("studentId");
            Integer htmlGap = (Integer) session.getAttribute("htmlGap");
            Integer javaGap = (Integer) session.getAttribute("javaGap");
            Integer sqlGap = (Integer) session.getAttribute("sqlGap");
            String htmlPriority = (String) session.getAttribute("htmlPriority");
            String javaPriority = (String) session.getAttribute("javaPriority");
            String sqlPriority = (String) session.getAttribute("sqlPriority");
            String overallPriority = (String) session.getAttribute("overallPriority");

            // Check if data exists
            if (studentObj == null) {
        %>
            <p style="color: red; text-align: center;">Error: No student data found. Please submit the form first.</p>
        <%
            } else {
                com.skillgap.model.Student student = (com.skillgap.model.Student) studentObj;
        %>
        <div class="report-container">
            <h1 class="report-title">📊 Skill Gap Analysis Report</h1>

            <!-- Student Information -->
            <div class="student-info">
                <h3 style="color: #667eea; margin-bottom: 15px;">Student Information</h3>
                <p><strong>Name:</strong> <%= student.getName() %></p>
                <p><strong>Email:</strong> <%= student.getEmail() %></p>
                <p><strong>Report Generated:</strong> <%= new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date()) %></p>
            </div>

            <!-- Overall Priority -->
            <div class="overall-section">
                <h2>Overall Priority Level</h2>
                <div class="overall-priority-value">
                    <% if ("High".equals(overallPriority)) { %>
                        🔴 HIGH PRIORITY
                    <% } else if ("Medium".equals(overallPriority)) { %>
                        🟡 MEDIUM PRIORITY
                    <% } else { %>
                        🟢 LOW PRIORITY
                    <% } %>
                </div>
                <p>You need immediate attention on skill development</p>
            </div>

            <!-- Skill Gap Table -->
            <h3 style="color: #667eea; margin-bottom: 15px;">Skill Details</h3>
            <table>
                <thead>
                    <tr>
                        <th>Skill</th>
                        <th>Your Level</th>
                        <th>Required Level</th>
                        <th>Gap</th>
                        <th>Priority</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>HTML</strong></td>
                        <td><%= student.getHtmlSkill() %>/10</td>
                        <td>9/10</td>
                        <td><span class="gap-value"><%= htmlGap > 0 ? "+" + htmlGap : htmlGap %></span></td>
                        <td>
                            <%
                                if ("High".equals(htmlPriority)) {
                            %>
                                <span class="priority-high">HIGH</span>
                            <%
                                } else if ("Medium".equals(htmlPriority)) {
                            %>
                                <span class="priority-medium">MEDIUM</span>
                            <%
                                } else {
                            %>
                                <span class="priority-low">LOW</span>
                            <%
                                }
                            %>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Java</strong></td>
                        <td><%= student.getJavaSkill() %>/10</td>
                        <td>8/10</td>
                        <td><span class="gap-value"><%= javaGap > 0 ? "+" + javaGap : javaGap %></span></td>
                        <td>
                            <%
                                if ("High".equals(javaPriority)) {
                            %>
                                <span class="priority-high">HIGH</span>
                            <%
                                } else if ("Medium".equals(javaPriority)) {
                            %>
                                <span class="priority-medium">MEDIUM</span>
                            <%
                                } else {
                            %>
                                <span class="priority-low">LOW</span>
                            <%
                                }
                            %>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>SQL</strong></td>
                        <td><%= student.getSqlSkill() %>/10</td>
                        <td>8/10</td>
                        <td><span class="gap-value"><%= sqlGap > 0 ? "+" + sqlGap : sqlGap %></span></td>
                        <td>
                            <%
                                if ("High".equals(sqlPriority)) {
                            %>
                                <span class="priority-high">HIGH</span>
                            <%
                                } else if ("Medium".equals(sqlPriority)) {
                            %>
                                <span class="priority-medium">MEDIUM</span>
                            <%
                                } else {
                            %>
                                <span class="priority-low">LOW</span>
                            <%
                                }
                            %>
                        </td>
                    </tr>
                </tbody>
            </table>

            <!-- Recommendations -->
            <div class="recommendations">
                <h3>💡 Personalized Recommendations</h3>
                <ul>
                    <%
                        if (htmlGap > 0) {
                    %>
                        <li><strong>HTML:</strong> Focus on advanced HTML5 features and semantic markup. Your gap is <%= htmlGap %> levels.</li>
                    <%
                        } else {
                    %>
                        <li><strong>HTML:</strong> ✓ Your HTML skills are at or above the required level. Great job!</li>
                    <%
                        }
                    %>

                    <%
                        if (javaGap > 0) {
                    %>
                        <li><strong>Java:</strong> Strengthen object-oriented programming concepts and design patterns. Your gap is <%= javaGap %> levels.</li>
                    <%
                        } else {
                    %>
                        <li><strong>Java:</strong> ✓ Your Java skills are at or above the required level. Excellent!</li>
                    <%
                        }
                    %>

                    <%
                        if (sqlGap > 0) {
                    %>
                        <li><strong>SQL:</strong> Work on complex queries, joins, and database optimization. Your gap is <%= sqlGap %> levels.</li>
                    <%
                        } else {
                    %>
                        <li><strong>SQL:</strong> ✓ Your SQL skills are at or above the required level. Well done!</li>
                    <%
                        }
                    %>
                </ul>
            </div>

            <!-- Action Buttons -->
            <div class="action-buttons">
                <a href="index.html" class="btn-secondary">← Back to Assessment</a>
                <button class="btn-primary" onclick="window.print()">🖨️ Print Report</button>
            </div>
        </div>
        <%
            }
        %>
    </div>
</body>
</html>
