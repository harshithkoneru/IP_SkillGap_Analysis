package com.skillgap.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.skillgap.model.Student;
import com.skillgap.db.DatabaseConnection;

@WebServlet("/submitSkills")
public class SkillGapServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Required skill levels (industry standard)
    private static final int REQUIRED_HTML = 9;
    private static final int REQUIRED_JAVA = 8;
    private static final int REQUIRED_SQL = 8;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        
        try {
            int htmlSkill = Integer.parseInt(request.getParameter("htmlSkill"));
            int javaSkill = Integer.parseInt(request.getParameter("javaSkill"));
            int sqlSkill = Integer.parseInt(request.getParameter("sqlSkill"));

            // Create Student object
            Student student = new Student(name, email, htmlSkill, javaSkill, sqlSkill);

            // Save student to database
            int studentId = saveStudent(student);

            // Calculate skill gaps
            int htmlGap = REQUIRED_HTML - htmlSkill;
            int javaGap = REQUIRED_JAVA - javaSkill;
            int sqlGap = REQUIRED_SQL - sqlSkill;

            // Determine priority levels
            String htmlPriority = determinePriority(htmlGap);
            String javaPriority = determinePriority(javaGap);
            String sqlPriority = determinePriority(sqlGap);

            // Determine overall priority
            String overallPriority = determineOverallPriority(htmlGap, javaGap, sqlGap);

            // Save skill gap report
            saveSkillGapReport(studentId, htmlGap, javaGap, sqlGap,
                    htmlPriority, javaPriority, sqlPriority, overallPriority);

            // Store data in session
            HttpSession session = request.getSession();
            session.setAttribute("studentId", studentId);
            session.setAttribute("student", student);
            session.setAttribute("htmlGap", htmlGap);
            session.setAttribute("javaGap", javaGap);
            session.setAttribute("sqlGap", sqlGap);
            session.setAttribute("htmlPriority", htmlPriority);
            session.setAttribute("javaPriority", javaPriority);
            session.setAttribute("sqlPriority", sqlPriority);
            session.setAttribute("overallPriority", overallPriority);

            // Redirect to report page
            response.sendRedirect("report.jsp");

        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid skill levels");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                    "Database error: " + e.getMessage());
        }
    }

    // Save student to database
    private int saveStudent(Student student) throws SQLException {
        String sql = "INSERT INTO students (name, email, html_skill, java_skill, sql_skill) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, student.getName());
            stmt.setString(2, student.getEmail());
            stmt.setInt(3, student.getHtmlSkill());
            stmt.setInt(4, student.getJavaSkill());
            stmt.setInt(5, student.getSqlSkill());
            
            stmt.executeUpdate();
            
            // Get generated student ID
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }
        }
        return -1;
    }

    // Save skill gap report to database
    private void saveSkillGapReport(int studentId, int htmlGap, int javaGap, int sqlGap,
            String htmlPriority, String javaPriority, String sqlPriority, String overallPriority)
            throws SQLException {
        
        String sql = "INSERT INTO skill_gap_reports (student_id, html_gap, java_gap, sql_gap, "
                + "html_priority, java_priority, sql_priority, overall_priority) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, studentId);
            stmt.setInt(2, htmlGap);
            stmt.setInt(3, javaGap);
            stmt.setInt(4, sqlGap);
            stmt.setString(5, htmlPriority);
            stmt.setString(6, javaPriority);
            stmt.setString(7, sqlPriority);
            stmt.setString(8, overallPriority);
            
            stmt.executeUpdate();
        }
    }

    // Determine priority based on gap
    // Rules:
    // IF gap >= 4 → High priority
    // IF gap between 2 and 3 → Medium
    // ELSE → Low
    private String determinePriority(int gap) {
        if (gap >= 4) {
            return "High";
        } else if (gap >= 2) {
            return "Medium";
        } else {
            return "Low";
        }
    }

    // Determine overall priority (highest priority among all skills)
    private String determineOverallPriority(int htmlGap, int javaGap, int sqlGap) {
        int maxGap = Math.max(htmlGap, Math.max(javaGap, sqlGap));
        
        if (maxGap >= 4) {
            return "High";
        } else if (maxGap >= 2) {
            return "Medium";
        } else {
            return "Low";
        }
    }
}
