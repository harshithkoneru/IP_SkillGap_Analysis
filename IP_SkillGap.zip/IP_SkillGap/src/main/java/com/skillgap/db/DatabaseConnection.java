package com.skillgap.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // Database credentials - Change these as per your setup
    private static final String DB_URL = "jdbc:mysql://localhost:3306/skillgap_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = ""; // Change if you have a password
    private static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";

    // Get database connection
    public static Connection getConnection() throws SQLException {
        try {
            // Load JDBC Driver
            Class.forName(DB_DRIVER);
            
            // Return connection
            return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found!");
            e.printStackTrace();
            throw new SQLException("Driver not loaded");
        }
    }
}
