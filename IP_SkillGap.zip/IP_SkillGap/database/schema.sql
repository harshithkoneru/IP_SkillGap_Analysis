-- Create Database
CREATE DATABASE IF NOT EXISTS skillgap_db;
USE skillgap_db;

-- Create Students Table
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    html_skill INT NOT NULL CHECK (html_skill BETWEEN 1 AND 10),
    java_skill INT NOT NULL CHECK (java_skill BETWEEN 1 AND 10),
    sql_skill INT NOT NULL CHECK (sql_skill BETWEEN 1 AND 10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Skill Gap Report Table
CREATE TABLE IF NOT EXISTS skill_gap_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    html_gap INT,
    java_gap INT,
    sql_gap INT,
    html_priority VARCHAR(20),
    java_priority VARCHAR(20),
    sql_priority VARCHAR(20),
    overall_priority VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id)
);
